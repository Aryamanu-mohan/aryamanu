from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader

def members(request):
  template = loader.get_template('index.html')
  context = {
    'username': 'ARYA(SREEDEVI)',
  }
  return HttpResponse(template.render(context, request))


def mem(request):
  template = loader.get_template('index.html')
  return HttpResponse(template.render())


def home(request):
    return render(request, 'index.html')

def testing(request):
  template = loader.get_template('template.html')
  context = {
    'greeting': 1,
  }
  return HttpResponse(template.render(context, request))                  