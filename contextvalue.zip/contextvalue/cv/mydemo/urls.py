from django.urls import path
from . import views

urlpatterns = [
    path('members/', views.members, name='index'),
    path('mem/', views.mem, name='index'),
    path('home/', views.home, name='index'),
    path('testing/', views.testing, name='template'),
]